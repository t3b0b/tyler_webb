from random import choice
from extensions import db
import random
from flask import Blueprint, render_template, redirect, url_for, request, jsonify, flash
from models import (User, Streak, Goals, Friendship, Notes, SharedItem, Notification,
                    Activity, Score, ToDoList, TopFive, SubTask)
from datetime import datetime, timedelta, date
from sqlalchemy import and_
from pmg_func import (common_route, add2db, getSwetime,get_user_goals,get_user_tasks,update_streak_details,
                      SortStreaks, filter_mod, create_notification)
import pandas as pd
from pytz import timezone
from flask_login import current_user, login_required
from sqlalchemy.orm import scoped_session

from classes.scoreHandler import ScoreAnalyzer,UserScores
from classes.calHandler import Calendar
from classes.textHandler import textHandler
from classes.plotHandler import PlotHandler

scorehand = ScoreAnalyzer()
datahand = PlotHandler()
texthand = textHandler()

tasks_bp = Blueprint('tasks', __name__, template_folder='templates/pmg')