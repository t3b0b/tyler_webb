from random import choice
from extensions import db

from flask import Blueprint, render_template, redirect, url_for, request, jsonify, flash
from models import (User, Streak, Goals, Friendship, Notes, SharedItem, Notification,
                    Activity, Score, ToDoList, TopFive, SubTask)
from datetime import datetime, timedelta, date

from pmg_func import (common_route, add2db, getSwetime, get_user_goals, get_user_tasks, update_streak_details,
                      SortStreaks, filter_mod, create_notification)
from flask_login import current_user, login_required

from classes.scoreHandler import ScoreAnalyzer, UserScores
from classes.calHandler import Calendar
from classes.textHandler import textHandler
from classes.plotHandler import PlotHandler

scorehand = ScoreAnalyzer()
datahand = PlotHandler()
texthand = textHandler()

activities_bp = Blueprint('activities', __name__, template_folder='templates/pmg')


@activities_bp.route('/goal/<int:goal_id>/activities', methods=['GET', 'POST'])
def goal_activities(goal_id):
    goal = Goals.query.get_or_404(goal_id)
    user = current_user.id
    shared_item = SharedItem.query.filter_by(item_id=goal_id, item_type='goal', status='active').first()
    start_activity = request.args.get('start_activity', None)

    if request.method == 'POST':
        # Hantera POST-begäran för att lägga till en aktivitet
        goalId = goal_id
        activity_name = request.form.get('activity-name')
        measurement = request.form.get('activity-measurement')

        if activity_name and measurement:
            # Skapa aktivitet
            new_activity = Activity(
                name=activity_name,
                goal_id=goal.id,
                user_id=user,
                shared_item_id=shared_item.id if shared_item else None  # Koppla till delning om målet är delat
            )
            db.session.add(new_activity)
            db.session.commit()

            if shared_item:
                # Hämta alla användare som målet är delat med
                shared_users = SharedItem.query.filter_by(item_id=goal_id, item_type='goal', status='active').all()
                for shared_user in shared_users:
                    if shared_user.shared_with_id != current_user.id:  # Hoppa över nuvarande användare
                        create_notification(
                            user_id=shared_user.shared_with_id,  # Mottagarens ID
                            message=f"{current_user.username} created a new activity '{activity_name}' in goal '{goal.name}'.",
                            related_item_id=new_activity.id,
                            item_type='activity'
                        )

            flash('Activity added successfully', 'success')
            return redirect(url_for('activities.goal_activities', goal_id=goal_id))
        else:
            flash('Activity name and measurement are required', 'danger')

    # Hantera GET-begäran för att visa aktiviteterna
    activities = Activity.query.filter_by(goal_id=goal_id).all()
    return render_template('pmg/activities.html', goal=goal, start_activity=start_activity, activities=activities)



# region Activity

@activities_bp.route('/update-task-order', methods=['POST'])
@login_required
def update_task_order():
    data = request.get_json()

    # Uppdatera ordningen för varje task och subtask
    for task_data in data:
        task_id = int(task_data['id'])
        task = ToDoList.query.get(task_id)
        if task:
            task.order = task_data['order']
            db.session.add(task)

        for subtask_data in task_data['subtasks']:
            subtask_id = int(subtask_data['id'])
            subtask = SubTask.query.get(subtask_id)
            if subtask:
                subtask.order = subtask_data['order']
                db.session.add(subtask)

    db.session.commit()
    return jsonify({'success': True})



@activities_bp.route('/delete-activity/<int:activity_id>', methods=['POST'])
@login_required
def delete_activity(activity_id):
    activity = Activity.query.get_or_404(activity_id)

    try:
        # Ta bort relaterade tasks
        ToDoList.query.filter_by(activity_id=activity.id).delete()

        # Ta bort relaterade notes
        Notes.query.filter_by(activity_id=activity.id).delete()

        # Ta bort själva aktiviteten
        db.session.delete(activity)
        db.session.commit()

        flash("Aktiviteten har tagits bort.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Något gick fel vid raderingen: {str(e)}", "danger")

    return redirect(url_for('pmg.activities'))


@activities_bp.route('/get_activities/<goal_id>')
def get_activities(goal_id):
    activities = Activity.query.filter_by(goal_id=goal_id)
    activity_list = [{'id': activity.id, 'name': activity.name} for activity in activities]

    return jsonify(activity_list)


@activities_bp.route('/update_note/<int:note_id>', methods=['POST'])
@login_required
def update_note(note_id):
    note = Notes.query.get_or_404(note_id)

    # Kontrollera om användaren äger anteckningen
    if note.user_id != current_user.id:
        flash('You are not authorized to edit this note.', 'danger')
        return redirect(url_for('pmg.goals'))  # Omdirigera om användaren inte äger anteckningen

    # Uppdatera innehållet från formuläret
    note.content = request.form.get('content')

    db.session.commit()
    flash('Note updated successfully!', 'success')

    return redirect(url_for('pmg.myday'))  # Omdirigera till lämplig sida efter uppdatering


@activities_bp.route('/create_notebook/<int:activity_id>', methods=['POST'])
@login_required
def create_notebook(activity_id):
    title = request.form.get('title')
    description = request.form.get('description')
    user = User.query.filter_by(id=current_user.id).first()

    new_note = Notes(
        title=title,
        content=description or '',
        user_id=current_user.id,
        author=user.username,
        activity_id=activity_id,
        date=datetime.now().strftime('%Y-%m-%d')
    )
    db.session.add(new_note)
    db.session.commit()

    flash('Notebook created successfully!', 'success')
    return redirect(url_for('pmg.focus_room', activity_id=activity_id))  # Omdirigera till mål-sidan eller var du vill


# endregion

# region Todos

@activities_bp.route('/activity/<int:activity_id>/tasks', methods=['GET'])
def activity_tasks(activity_id):
    # Hämta aktiviteten
    activity = Activity.query.get_or_404(activity_id)

    # Kontrollera om användaren har åtkomst till aktiviteten
    if activity.goal_id not in [goal.id for goal in get_user_goals(current_user.id)]:
        flash("Du har inte behörighet att visa denna aktivitet.", "danger")
        return redirect(url_for('pmg.myday'))  # Omdirigera till en lämplig sida

    # Hämta tasks och subtasks kopplade till aktiviteten
    todos = get_user_tasks(current_user.id, Activity, activity_id)  # Använd den uppdaterade funktionen

    sida = f"{activity.name} ToDos"
    return render_template('pmg/activity_tasks.html', activity=activity, tasks=todos, sida=sida, header=sida)


@activities_bp.route('/activity/<int:activity_id>/update_task/<int:task_id>', methods=['GET', 'POST'])
def update_task(activity_id, task_id):
    task = ToDoList.query.get_or_404(task_id)

    # Hämta den nya statusen från formuläret
    completed = 'completed' in request.form  # Checkbox skickar bara värde om den är markerad
    page = request.form.get('page')  # Hämta ursprungssidan

    # Uppdatera task status
    task.completed = completed
    db.session.commit()

    # Omdirigera till rätt sida baserat på ursprungssidan
    if page == 'todo':
        return redirect(url_for('pmg.activity_tasks', activity_id=activity_id))
    elif page == 'focus':
        return redirect(url_for('pmg.focus_room', activity_id=activity_id))

    # Om ingen origin skickas med, omdirigera till standard-sidan
    return redirect(url_for('pmg.activity_tasks', activity_id=activity_id))


@activities_bp.route('/activity/<int:activity_id>/add_task', methods=['POST'])
def add_task(activity_id):
    # Hämta aktiviteten
    activity = Activity.query.get_or_404(activity_id)

    # Kontrollera om aktiviteten är kopplad till ett SharedItem
    shared_item = SharedItem.query.filter_by(
        id=activity.shared_item_id
    ).first()

    # Hämta data från formuläret
    task_name = request.form.get('task_name')
    is_repeatable = request.form.get('is_repeatable') == 'true'
    total_repeats = request.form.get('total_repeats', type=int)

    # Validera task-namn
    if not task_name:
        flash("Task name is required", "danger")
        return redirect(url_for('pmg.activity_tasks', activity_id=activity_id))

    # Skapa ny task
    new_task = ToDoList(
        task=task_name,
        completed=False,
        is_repeatable=is_repeatable,
        total_repeats=total_repeats if is_repeatable else None,
        user_id=current_user.id,
        activity_id=activity.id,
        shared_item_id=shared_item.id if shared_item else None
    )

    db.session.add(new_task)
    db.session.commit()

    if shared_item:
        # Hämta alla användare som delar aktiviteten
        shared_users = SharedItem.query.filter_by(item_id=activity.id, item_type='activity', status='active').all()
        for shared_user in shared_users:
            if shared_user.shared_with_id != current_user.id:
                create_notification(
                    user_id=shared_user.shared_with_id,
                    message=f"{current_user.username} added the task '{task_name}' to '{activity.name}'.",
                    related_item_id=new_task.id,
                    item_type='task'
                )
    if 'fokus' in request.form.get('page'):
        flash("Task added successfully", "success")
        return redirect(url_for('pmg.focus_room', activity_id=activity_id))
    elif 'list' in request.form.get('page'):
        flash("Task added successfully", "success")
        return redirect(url_for('pmg.activity_tasks', activity_id=activity_id))


@activities_bp.route('/activity/<int:activity_id>/delete_task/<int:task_id>', methods=['POST'])
@login_required
def delete_task(activity_id, task_id):
    # Hämta tasken
    task = ToDoList.query.get_or_404(task_id)

    # Kontrollera om användaren har åtkomst till aktiviteten
    if task.activity_id != activity_id:
        flash("Ogiltig förfrågan: Aktiviteten matchar inte.", "danger")
        return redirect(url_for('pmg.activity_tasks', activity_id=activity_id))

    # Kontrollera om användaren är ägare till tasken eller att aktiviteten är delad
    if not current_user.id == task.user_id:
        flash("Du har inte behörighet att ta bort denna task.", "danger")
        return redirect(url_for('pmg.activity_tasks', activity_id=activity_id))

    try:
        db.session.delete(task)
        db.session.commit()
        flash("Task raderades framgångsrikt.", "success")
    except Exception as e:
        db.session.rollback()
        flash(f"Något gick fel vid raderingen: {str(e)}", "danger")

    return redirect(url_for('pmg.activity_tasks', activity_id=activity_id))


# endregion

# region Subtasks
@activities_bp.route('/task/<int:task_id>/add_subtask', methods=['POST'])
@login_required
def add_subtask(task_id):
    task = ToDoList.query.get_or_404(task_id)
    subtask_name = request.form.get('subtask_name')

    if not subtask_name:
        flash("Subtask name is required", "danger")
        return redirect(url_for('pmg.activity_tasks', activity_id=task.activity_id))

    new_subtask = SubTask(name=subtask_name, task_id=task_id)
    db.session.add(new_subtask)

    task.completed = False

    db.session.commit()

    if 'fokus' in request.form.get('page'):
        flash("Subtask added successfully!", "success")
        return redirect(url_for('pmg.focus_room', activity_id=task.activity_id))
    elif 'list' in request.form.get('page'):
        flash("Subtask added successfully!", "success")
        return redirect(url_for('pmg.activity_tasks', activity_id=task.activity_id))


@activities_bp.route('/subtask/<int:subtask_id>/update', methods=['POST'])
def update_subtask(subtask_id):
    subtask = SubTask.query.get_or_404(subtask_id)
    subtask.completed = not subtask.completed  # Växla status på subtask
    db.session.commit()

    # 🟢 Hämta alla subtasks för denna task
    all_subtasks = SubTask.query.filter_by(task_id=subtask.task_id).all()
    task = ToDoList.query.get(subtask.task_id)

    # 🔍 Kontrollera om alla subtasks är avklarade
    if all(sub.completed for sub in all_subtasks):  # Om alla subtasks är klara
        task.completed = True
    else:
        task.completed = False  # Om minst en subtask är ofullständig

    db.session.commit()  # Spara ändringar till databasen

    # Omdirigera tillbaka till rätt sida
    if 'fokus' in request.form.get('page'):
        return redirect(url_for('pmg.focus_room', activity_id=task.activity_id))
    elif 'list' in request.form.get('page'):
        return redirect(url_for('pmg.activity_tasks', activity_id=task.activity_id))


@activities_bp.route('/task/<int:task_id>/subtasks', methods=['GET'])
@login_required
def get_subtasks(task_id):
    task = ToDoList.query.get_or_404(task_id)
    subtasks = SubTask.query.filter_by(task_id=task_id).order_by(SubTask.completed.asc()).all()

    return render_template('pmg/subtasks.html', task=task, subtasks=subtasks)

# endregion